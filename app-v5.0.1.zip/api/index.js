'use strict';

var express = require('express');
var Blog = require('../data/models/blog');
var User = require('../data/models/user');

var router = express.Router();

router.get('/users', function(req, res) {
  User.find({}, function(err, users) {
    if (err) {
      return res.status(500).json({ message: err.message });
    }
    res.json({ users: users });
  });
});

router.get('/user/:id', function(req, res) {
  var id = req.params.id;
  User.findOne({_id: id}, function(err, user) {
    if (err) {
      return res.status(500).json({message: err.message});
    }
    Blog.find({author: user._id}, function(err, blogs){
      console.log(err);
      res.json({user: user, blogs: blogs});
    });

  });
});

router.get('/blogs', function(req, res) {
  Blog.find({}, function(err, blogs) {
    if (err) {
      return res.status(500).json({ message: err.message });
    }
    res.json({ blogs: blogs });
  });
});

router.get('/blog/:id', function(req, res) {
  var id = req.params.id;
  Blog.findOne({_id: id}, function(err, blog) {
    if (err) {
      return res.status(500).json({message: err.message});
    }
    User.find({_id: blog.author}, function(err, author){
      console.log(author);
      res.json({blog: blog, author: author});
    });
  });
});

module.exports = router;

//
// router.post('/todos', function(req, res) {
//   var todo = req.body;
//   Todo.create(todo, function(err, todo) {
//     if (err) {
//       return res.status(500).json({ err: err.message });
//     }
//     res.json({ 'todo': todo, message: 'Todo Created' });
//   });
// });
//
// router.put('/todos/:id', function(req, res) {
//   var id = req.params.id;
//   var todo = req.body;
//   if (todo && todo._id !== id) {
//     return res.status(500).json({ err: "Ids don't match!" });
//   }
//   Todo.findByIdAndUpdate(id, todo, {new: true}, function(err, todo) {
//     if (err) {
//       return res.status(500).json({ err: err.message });
//     }
//     res.json({ 'todo': todo, message: 'Todo Updated' });
//   });
// });
//
// // TODO: Add DELETE route to remove existing entries
//
